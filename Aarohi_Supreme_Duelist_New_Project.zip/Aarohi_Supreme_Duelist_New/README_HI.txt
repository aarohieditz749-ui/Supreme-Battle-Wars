AAROHI SUPREME DUELIST — नया Android Studio प्रोजेक्ट

इस ZIP में नया प्रोजेक्ट शून्य से बनाया गया है; किसी पुरानी ZIP का उपयोग नहीं किया गया।

शामिल:
- Android WebView wrapper (landscape)
- HTML5 Canvas arena prototype
- CPU Battle, 2 Player, Survival entry buttons
- Touch controls, jump, hit, throw
- Duel Coins, XP, wins और local save
- Skin selector, daily reward और mission info

जरूरी सीमा:
यह शुरुआती playable prototype है, पूर्ण Supreme Duelist feature-complete game नहीं।
66 हथियार, tournament bracket, advanced ragdoll physics, full survival waves, shop/unlock economy और polished animation अभी implement नहीं हैं।
इस वातावरण में Android SDK/Gradle build चलाकर APK compile/test नहीं किया गया। इसलिए इस ZIP में APK शामिल नहीं है।

APK बनाने के लिए:
1. Android Studio में इस फ़ोल्डर को Open करें।
2. Gradle sync पूरा होने दें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. APK app/build/outputs/apk/debug/ में मिलेगी।
