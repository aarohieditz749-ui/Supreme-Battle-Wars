package com.aarohi.supremeduelist;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.View;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512|4096); WebView w=new WebView(this); w.setBackgroundColor(0xff090d1c); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); w.loadUrl("file:///android_asset/index.html"); setContentView(w); }
 @Override public void onBackPressed(){ }
}
